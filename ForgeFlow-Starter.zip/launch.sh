#!/bin/bash
echo 'Launch script'